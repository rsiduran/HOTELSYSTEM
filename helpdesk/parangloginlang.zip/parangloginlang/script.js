var btnLogin = document.getElementById('do-Submit');
var idLogin = document.getElementById('Submit');
var username = document.getElementById('username');
btnLogin.onclick = function(){
  idLogin.innerHTML = '<p>Welcome To Nice Hotel Helpdesk</p><h1>' +username.value+ '</h1>';
} 